import React, { useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { useQuery } from '@wasp/queries';
import { useAction } from '@wasp/actions';
import getArticle from '@wasp/queries/getArticle';
import updateArticle from '@wasp/actions/updateArticle';

export function Article() {
  const { articleId } = useParams();
  const { data: article, isLoading, error } = useQuery(getArticle, { id: articleId });
  const updateArticleFn = useAction(updateArticle);
  const [updatedTitle, setUpdatedTitle] = useState('');

  if (isLoading) return 'Loading...';
  if (error) return 'Error: ' + error;

  const handleUpdateTitle = () => {
    updateArticleFn({ id: article.id, updatedTitle });
    setUpdatedTitle('');
  };

  return (
    <div className='p-4'>
      <div className='mb-4'>
        <input
          type='text'
          placeholder='Update Title'
          className='px-1 py-2 border rounded text-lg'
          value={updatedTitle}
          onChange={(e) => setUpdatedTitle(e.target.value)}
        />
        <button
          onClick={handleUpdateTitle}
          className='bg-blue-500 hover:bg-blue-700 px-2 py-2 text-white font-bold rounded ml-2'
        >
          Update
        </button>
      </div>
      <div>
        <h2 className='text-2xl font-bold mb-4'>{article.title}</h2>
        <p>{article.content}</p>
      </div>
    </div>
  );
}