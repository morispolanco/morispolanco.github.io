import React from 'react';
import { Link } from 'react-router-dom';
import { useQuery } from '@wasp/queries';
import getUserArticles from '@wasp/queries/getUserArticles';

export function DashboardPage() {
  const { data: articles, isLoading, error } = useQuery(getUserArticles);

  if (isLoading) return 'Loading...';
  if (error) return 'Error: ' + error;

  return (
    <div>
      {articles.map((article) => (
        <div key={article.id}>
          <h2>{article.title}</h2>
          <p>{article.content}</p>
          <Link to={`/article/${article.id}`}>Read More</Link>
        </div>
      ))}
    </div>
  );
}