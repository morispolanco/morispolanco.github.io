import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { useAction } from '@wasp/actions';
import createArticle from '@wasp/actions/createArticle';

export function CreateArticle() {
  const createArticleFn = useAction(createArticle);
  const [title, setTitle] = useState('');

  const handleCreateArticle = async () => {
    try {
      await createArticleFn({ title });
      // Success message or redirect to article page
    } catch (error) {
      // Error message
    }
  };

  return (
    <div className='p-4'>
      <input
        type="text"
        placeholder="Article Title"
        className="px-2 py-1 border rounded"
        value={title}
        onChange={(e) => setTitle(e.target.value)}
      />
      <button
        onClick={handleCreateArticle}
        className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded mt-2"
      >
        Create Article
      </button>
      <Link to="/dashboard" className="bg-red-500 hover:bg-red-700 text-white font-bold py-2 px-4 rounded ml-2">
        Cancel
      </Link>
    </div>
  );
}