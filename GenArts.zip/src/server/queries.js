import HttpError from '@wasp/core/HttpError.js'

export const getArticle = async ({ id }, context) => {
  if (!context.user) { throw new HttpError(401) }

  const article = await context.entities.Article.findUnique({
    where: { id, userId: context.user.id }
  });

  if (!article) { throw new HttpError(400) }

  return article;
}

export const getUserArticles = async (args, context) => {
  if (!context.user) { throw new HttpError(401) };

  return context.entities.Article.findMany({
    where: {
      user: { id: context.user.id }
    }
  });
}